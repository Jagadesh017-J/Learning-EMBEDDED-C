#include <LPC21xx.h>
#include "Delay.h"
#include "LCD HEADER.h"
#include "types.h"
#include "i2c.h"
#include "i2c_eeprom.h"
#define SW1 15
#define SW2 16
#define LED1 17
#define LED2 18
#define LED3 19
#define LED4 20
#define LED5 21
int main()
{
	unsigned char total=0,pre1=0,pre2=0,cur_1,cur_2;
	IODIR0 |=(1<<LED1)|(1<<LED2)|(1<<LED3)|(1<<LED4)|(1<<LED5);
	total=i2c_eeprom_read(0X68,0X00);
  
	while(1)
    {
      
			cur_1=(IOPIN0&(1<<SW1))?1:0;
			cur_2=(IOPIN0&(1<<SW2))?1:0;
			if(cur_1==1&pre1==0)
			{
				total++;
				i2c_eeprom_write(0x68,0X00,total);
              
				if(total<=1)
					IOCLR0=1<<LED1;
				else if(total<=3)
					IOCLR0=(1<<LED1)|(1<<LED2)|(1<<LED3);
				else if(total>=5)
					IOCLR0=(1<<LED1)|(1<<LED2)|(1<<LED3)|(1<<LED4)|(1<<LED5);
					
			}
			else if(cur_2==1&pre2==0)
			{
				total--;
				i2c_eeprom_write(0X68,0X00,total);
				if(total<=1)
					IOSET0=(1<<LED1);
				else if(total<=3)
					IOSET0=(1<<LED1)|(1<<LED2)|(1<<LED3);
				else if(total>=5)
					IOSET0=(1<<LED1)|(1<<LED2)|(1<<LED3)|(1<<LED4)|(1<<LED5);
					
			}
      
			pre1=cur_1;
			pre2=cur_2;
		}
		
	}		