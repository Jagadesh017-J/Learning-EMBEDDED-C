#include <LPC21xx.h>


#include "Delay.h"
#include "LCD HEADER.h"
#include "types.h"
#include "i2c.h"
#include "i2c_eeprom.h"


/*#define SW1 14
#define SW2 15 */


#define LED1 20
#define LED2 21
#define LED3 22
#define LED4 23
#define LED5 24


unsigned char total=0;

void EXT0_CONF();

void EXT0_ISR() __irq
{
EXTINT=0X01;
total++;
VICVectAddr=0;
}

void EXT1_ISR() __irq
{
EXTINT=0X02;
total--;
VICVectAddr=0;
}

void EXT0_CONF()
{
 VICIntSelect=0;
 VICVectCntl0=0x20|14;
 VICVectAddr0=(int)EXT0_ISR;

 VICVectCntl1=0x20|15;
 VICVectAddr1=(int)EXT1_ISR;
}
 
 	

int main()
{
 PINSEL1|=0X01;
 PINSEL0|=0X20000000;
 IODIR0|=LED1|LED2|LED3|LED4|LED5;
 EXT0_CONF();
 EXTMODE=0X03;
 EXTPOLAR=0X00;

 VICIntEnable=1<<14|1<<15;
 while(1)
 {
 				if(total<=1)
				{
					IOSET0|=1<<LED1;
					 IOCLR0|=(1<<LED2)|(1<<LED3)|(1<<LED4)|(1<<LED5);
				}
				else if(total<=3)
				{
					IOSET0|=(1<<LED1)|(1<<LED2)|(1<<LED3);
					IOCLR0|=(1<<LED4)|(1<<LED5);
					}
				else if(total>=5)
				{
					IOSET0|=(1<<LED1)|(1<<LED2)|(1<<LED3)|(1<<LED4)|(1<<LED5);
				}
 }

 }
